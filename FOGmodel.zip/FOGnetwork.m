function GN = FOGnetwork(pd,stim,freq)

%Usage: GN = FOGnetwork(pd,stim,freq)
%
%Example: error_index=BG(1,1,130);
%
%Variables:
%pd - Variable to determine whether network is under the healthy or 
%Parkinsonian condition. For healthy, pd = 0, for Parkinson's, pd = 1.
%stim - Variable to determine whether deep brain stimulation is on.
%If DBS is off, stim = 0. If DBS is on, stim = 1.
%freq - Determines the frequency of stimulation, in Hz.
%
%
%Author: Mariia Popova, UKE; based on Rosa So, Duke University 
%Updated 27/05/2020

load('Istim.mat') %loads initial conditions %what is r?
addpath('gating')

%Membrane parameters
Cm=1; 
%In order of Th,STN,GP or Th,STN,GPe,GPi
gl=[0.05 2.25 0.1]; El=[-70 -60 -65];
gna=[3 37 120]; Ena=[50 55 55]; 
gk=[5 45 30]; Ek=[-75 -80 -80];
gt=[5 0.5 0.5]; Et=0;
gca=[0 2 0.15]; Eca=[0 140 120];
gahp=[0 20 10]; %eahp and ek are the same excluding th
k1=[0 15 10]; %dissociation const of ahp current 
kca=[0 22.5 15]; %calcium pump rate constant
A=[0 3 2 2]; %params for synapses %why so many if need only for gpe
B=[0 0.1 0.04 0.04]; %params for synapses %why so many if need only for gpe
the=[0 30 20 20]; %params for synapses %why so many if need only for gpe

%%Synapse parameters
%In order of Igesn,Isnge,Igege,Isngi,Igegi,Igith 
gsyn = [1 0.3 1 0.3 1 .08]; Esyn = [-85 0 -85 0 -85 -85]; %alike in Rubin gsyn and in So Esyn
tau=5; gpeak1=0.3; gpeak=0.43; %parameters for second-order alpha synapse

%time step
t=0:dt:tmax;

%%Setting initial matrices
%n - number of neurons in each population
vth=zeros(n,length(t)); %thalamic membrane voltage
vsn=zeros(n,length(t)); %STN membrane voltage
vge=zeros(n,length(t)); %GPe membrane voltage
vgi=zeros(n,length(t)); %GPi membrane voltage
Z4=zeros(n,1); %for 2 order alpha-synapse gpi-th current
S4=zeros(n,1); %for alpha-synapse gpi-th current
S3=zeros(n,1); %for alpha-synapse gesn current
S31=zeros(n,1);%for dummy gesn current
S2=zeros(n,1); %for alpha-synapse snge current
Z2=zeros(n,1); %for 2 order alpha-synapse sn current
S21=zeros(n,1); %for dummy snge current
S32=zeros(n,1); %for dummy gege current


%%with or without DBS
Idbs=createdbs(freq,tmax,dt); %creating DBS train with frequency freq
if ~stim; Idbs=zeros(1,length(t)); end

%%initial conditions 
vth(:,1)=v1;
vsn(:,1)=v2;
vge(:,1)=v3;
vgi(:,1)=v4;

%helper variables for gating and synapse params - starting parameters
R2=stn_rinf(vsn(:,1)); %r for stn
H1=th_hinf(vth(:,1)); %h for th
R1=th_rinf(vth(:,1)); %r for th
N2=stn_ninf(vsn(:,1));%n for stn
H2=stn_hinf(vsn(:,1));%h for stn
C2=stn_cinf(vsn(:,1));%c for stn
CA2=0.1; %intracellular concentration of Ca2+ in muM for stn
CA3=CA2; %for gpe
CA4=CA2; %for gpi
N3=gpe_ninf(vge(:,1));%n for gpe
H3=gpe_hinf(vge(:,1));%h for gpe
R3=gpe_rinf(vge(:,1));%r for gpe
N4=gpe_ninf(vgi(:,1));%n for gpi
H4=gpe_hinf(vgi(:,1));%h for gpi
R4=gpe_rinf(vgi(:,1));%r for gpi

%%Time loop
for i=2:length(t)        
    V1=vth(:,i-1);    V2=vsn(:,i-1);     V3=vge(:,i-1);    V4=vgi(:,i-1); %previous values
    % Synapse parameters 
    S21(2:n)=S2(1:n-1);S21(1)=S2(n); %dummy synapse for snge current as there is 1 stn to 2 ge
    S31(1:n-1)=S3(2:n);S31(n)=S3(1); %dummy synapse for gesn current as there is 1 ge to 2 stn
    S32(3:n)=S3(1:n-2);S32(1:2)=S3(n-1:n); %dummy synapse for gege current as there is 1 ge to 2 ge
    
    %membrane parameters - gating variables
    m1=th_minf(V1);m2=stn_minf(V2);m3=gpe_minf(V3);m4=gpe_minf(V4); %gpe and gpi are modeled similarily
    n2=stn_ninf(V2);n3=gpe_ninf(V3);n4=gpe_ninf(V4);
    h1=th_hinf(V1);h2=stn_hinf(V2);h3=gpe_hinf(V3);h4=gpe_hinf(V4);
    p1=th_pinf(V1);
    a2=stn_ainf(V2); a3=gpe_ainf(V3);a4=gpe_ainf(V4); %for low-treshold ca
    b2=stn_binf(R2);
    s3=gpe_sinf(V3);s4=gpe_sinf(V4);
    r1=th_rinf(V1);r2=stn_rinf(V2);r3=gpe_rinf(V3);r4=gpe_rinf(V4);
    c2=stn_cinf(V2);

    %membrane parameters - time constants
    tn2=stn_taun(V2);tn3=gpe_taun(V3);tn4=gpe_taun(V4);
    th1=th_tauh(V1);th2=stn_tauh(V2);th3=gpe_tauh(V3);th4=gpe_tauh(V4);
    tr1=th_taur(V1);tr2=stn_taur(V2);tr3=30;tr4=30;
    tc2=stn_tauc(V2);
    
    %thalamic cell currents
    Il1=gl(1)*(V1-El(1));
    Ina1=gna(1)*(m1.^3).*H1.*(V1-Ena(1));
    Ik1=gk(1)*((0.75*(1-H1)).^4).*(V1-Ek(1)); %misspelled in So paper
    It1=gt(1)*(p1.^2).*R1.*(V1-Et);
    Igith=1.4*gsyn(6)*(V1-Esyn(6)).*S4; %for alpha-synapse second order kinetics
    
    %STN cell currents
    Il2=gl(2)*(V2-El(2));
    Ik2=gk(2)*(N2.^4).*(V2-Ek(2));
    Ina2=gna(2)*(m2.^3).*H2.*(V2-Ena(2));
    It2=gt(2)*(a2.^3).*(b2.^2).*(V2-Eca(2)); %misspelled in So paper
    Ica2=gca(2)*(C2.^2).*(V2-Eca(2));
    Iahp2=gahp(2)*(V2-Ek(2)).*(CA2./(CA2+k1(2))); %cause ek and eahp are the same
    Igesn=0.5*(gsyn(1)*(V2-Esyn(1)).*(S3+S31)); %first-order kinetics 1ge to 2sn
    Iappstn=33-pd*10; %to switch between parkinsonian and healthy state
    
    %GPe cell currents
    Il3=gl(3)*(V3-El(3));
    Ik3=gk(3)*(N3.^4).*(V3-Ek(3));
    Ina3=gna(3)*(m3.^3).*H3.*(V3-Ena(3));
    It3=gt(3)*(a3.^3).*R3.*(V3-Eca(3)); %Eca as in Rubin and Terman
    Ica3=gca(3)*(s3.^2).*(V3-Eca(3)); %misspelled in So paper
    Iahp3=gahp(3)*(V3-Ek(3)).*(CA3./(CA3+k1(3))); %as Ek is the same with Eahp
    Isnge=0.5*(gsyn(2)*(V3-Esyn(2)).*(S2+S21)); %second-order kinetics 1sn to 2ge
    Igege=0.5*(gsyn(3)*(V3-Esyn(3)).*(S31+S32)); %first-order kinetics 1ge to 2ge
    Iappgpe=21-13*pd+r; %why need r??

    %GPi cell currents
    Il4=gl(3)*(V4-El(3));
    Ik4=gk(3)*(N4.^4).*(V4-Ek(3));
    Ina4=gna(3)*(m4.^3).*H4.*(V4-Ena(3)); %Eca as in Rubin and Terman
    It4=gt(3)*(a4.^3).*R4.*(V4-Eca(3)); %misspelled in So paper
    Ica4=gca(3)*(s4.^2).*(V4-Eca(3)); %as Ek is the same with Eahp
    Iahp4=gahp(3)*(V4-Ek(3)).*(CA4./(CA4+k1(3)));
    Isngi=0.5*(gsyn(4)*(V4-Esyn(4)).*(S2+S21)); %second-order kinetics 1sn to 2gi
    Igegi=0.5*(gsyn(5)*(V4-Esyn(5)).*(S31+S32)); %first-order kinetics 1ge to 2gi
    Iappgpi=22-pd*6;
    
    %Differential Equations for cells using forward Euler method
    %thalamic
    vth(:,i)= V1+dt*(1/Cm*(-Il1-Ik1-Ina1-It1-Igith+Istim(i)));
    H1=H1+dt*((h1-H1)./th1);
    R1=R1+dt*((r1-R1)./tr1);
    
    %STN
    vsn(:,i)=V2+dt*(1/Cm*(-Il2-Ik2-Ina2-It2-Ica2-Iahp2-Igesn+Iappstn+Idbs(i))); %currently STN-DBS
    N2=N2+dt*(0.75*(n2-N2)./tn2); 
    H2=H2+dt*(0.75*(h2-H2)./th2);
    R2=R2+dt*(0.2*(r2-R2)./tr2);
    CA2=CA2+dt*(3.75*10^-5*(-Ica2-It2-kca(2)*CA2));
    C2=C2+dt*(0.08*(c2-C2)./tc2); 
    %for second order second-order alpha-synapse
    a=find(vsn(:,i-1)<-10 & vsn(:,i)>-10);
    u=zeros(n,1); u(a)=gpeak/(tau*exp(-1))/dt; 
    S2=S2+dt*Z2; 
    zdot=u-2/tau*Z2-1/(tau^2)*S2;
    Z2=Z2+dt*zdot;
    
    %GPe
    vge(:,i)=V3+dt*(1/Cm*(-Il3-Ik3-Ina3-It3-Ica3-Iahp3-Isnge-Igege+Iappgpe));
    N3=N3+dt*(0.1*(n3-N3)./tn3); %misspelled in So paper
    H3=H3+dt*(0.05*(h3-H3)./th3); %misspelled in So paper
    R3=R3+dt*(1*(r3-R3)./tr3); %misspelled in So paper
    CA3=CA3+dt*(1*10^-4*(-Ica3-It3-kca(3)*CA3));
    S3=S3+dt*(A(3)*(1-S3).*Hinf(V3-the(3))-B(3)*S3);
    
    %GPi
    vgi(:,i)=V4+dt*(1/Cm*(-Il4-Ik4-Ina4-It4-Ica4-Iahp4-Isngi-Igegi+Iappgpi));
    N4=N4+dt*(0.1*(n4-N4)./tn4); %misspelled in So paper
    H4=H4+dt*(0.05*(h4-H4)./th4); %misspelled in So paper
    R4=R4+dt*(1*(r4-R4)./tr4); %misspelled in So paper
    CA4=CA4+dt*(1*10^-4*(-Ica4-It4-kca(3)*CA4));
    %for second order second-order alpha-synapse
    a=find(vgi(:,i-1)<-10 & vgi(:,i)>-10);
    u=zeros(n,1); u(a)=gpeak1/(tau*exp(-1))/dt; 
    S4=S4+dt*Z4; 
    zdot=u-2/tau*Z4-1/(tau^2)*S4;
    Z4=Z4+dt*zdot;
end

%%Calculation of error index
GN=calculateEI(t,vth,timespike,tmax);

%%Plots membrane potential for one cell in each nucleus
plotpotentials; 

return
