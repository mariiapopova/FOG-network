function hinf=th_hinf(V)
hinf=1./(1+exp((V+41)./4));
return