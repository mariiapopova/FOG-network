function rinf=th_rinf(V)
rinf=1./(1+exp((V+84)./4));
return