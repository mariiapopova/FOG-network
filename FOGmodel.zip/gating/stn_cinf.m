function cinf=stn_cinf(V)
cinf=1./(1+exp(-(V+20)/8));
return