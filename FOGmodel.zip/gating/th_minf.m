function minf=th_minf(V)
minf=1./(1+exp(-(V+37)./7));
return