function hinf=gpe_hinf(V)
hinf=1./(1+exp((V+58)./12));
return