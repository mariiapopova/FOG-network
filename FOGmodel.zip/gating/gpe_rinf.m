function rinf=gpe_rinf(V)
rinf=1./(1+exp((V+70)./2));
return