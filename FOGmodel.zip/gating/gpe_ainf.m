function ainf=gpe_ainf(V)
ainf=1./(1+exp(-(V+57)./2));
return