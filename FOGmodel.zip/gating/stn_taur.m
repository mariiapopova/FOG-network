function tau=stn_taur(V)
tau=7.1+17.5./(1+exp(-(V-68)./-2.2));
return