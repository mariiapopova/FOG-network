function hinf=stn_hinf(V)
hinf=1./(1+exp((V+39)./3.1));
return