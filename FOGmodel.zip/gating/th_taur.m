function tau=th_taur(V)
tau=0.15*(28+exp(-(V+25)./10.5));
return